import streamlit as st
import plotly.express as px

from utils.data_loader import load_data

df = load_data()

st.title("📦 Category Analysis")

tab1, tab2, tab3 = st.tabs(
    [
        "Category",
        "Sub Category",
        "Insights"
    ]
)

with tab1:

    st.subheader("Sales by Category")

    category_sales = (
        df.groupby("Category")["Sales"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        category_sales,
        x="Category",
        y="Sales",
        color="Category",
        text_auto=".2s",
        title="Sales by Category"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

    st.subheader("Profit by Category")

    category_profit = (
        df.groupby("Category")["Profit"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        category_profit,
        x="Category",
        y="Profit",
        color="Category",
        text_auto=".2s",
        title="Profit by Category"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    
with tab2:

    st.subheader("Top 10 Sub-Categories by Sales")

    top_sales = (
        df.groupby("Sub-Category")["Sales"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    fig = px.bar(
        top_sales,
        x="Sales",
        y="Sub-Category",
        orientation="h",
        text_auto=".2s",
        title="Top Sub-Categories by Sales"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    
    st.subheader("Top 10 Sub-Categories by Profit")

    top_profit = (
        df.groupby("Sub-Category")["Profit"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    fig = px.bar(
        top_profit,
        x="Profit",
        y="Sub-Category",
        orientation="h",
        text_auto=".2s",
        title="Top Sub-Categories by Profit"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    st.subheader("Loss Making Sub-Categories")

    loss_df = (
        df.groupby("Sub-Category")["Profit"]
        .sum()
        .sort_values()
        .head(5)
        .reset_index()
    )

    fig = px.bar(
        loss_df,
        x="Profit",
        y="Sub-Category",
        orientation="h",
        color="Profit",
        title="Lowest Profit Sub-Categories"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
with tab3:

    st.subheader("📌 Key Findings")

    st.success("""
    Technology generated the highest overall sales.
    """)

    st.success("""
    Technology generated the highest overall profit.
    """)

    st.warning("""
    Tables generated losses despite strong sales.
    """)

    st.warning("""
    Bookcases also contributed negative profit.
    """)

    st.info("""
    Copiers delivered the highest profit among all sub-categories.
    """)