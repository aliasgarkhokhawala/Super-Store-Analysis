import streamlit as st
import plotly.express as px

from utils.data_loader import load_data


st.title("🚀 Advanced Analytics")


df = load_data()


st.sidebar.header("Filters")

selected_category = st.sidebar.multiselect(
    "Select Category",
    options=df["Category"].unique(),
    default=df["Category"].unique()
)

selected_region = st.sidebar.multiselect(
    "Select Region",
    options=df["Region"].unique(),
    default=df["Region"].unique()
)


filtered_df = df[
    (df["Category"].isin(selected_category))
    &
    (df["Region"].isin(selected_region))
]


sales = filtered_df["Sales"].sum()
profit = filtered_df["Profit"].sum()
quantity = filtered_df["Quantity"].sum()

col1, col2, col3 = st.columns(3)

with col1:
    st.metric(
        "💰 Total Sales",
        f"${sales:,.0f}"
    )

with col2:
    st.metric(
        "📈 Total Profit",
        f"${profit:,.0f}"
    )

with col3:
    st.metric(
        "📦 Quantity Sold",
        f"{quantity:,}"
    )

st.divider()


st.subheader("3D Product Performance Analysis")

fig = px.scatter_3d(
    filtered_df,
    x="Sales",
    y="Profit",
    z="Quantity",
    color="Discount",
    hover_name="Product Name",
    title="Sales vs Profit vs Quantity",
    height=700
)

st.plotly_chart(
    fig,
    use_container_width=True
)


st.subheader("Sales vs Profit")

fig = px.scatter(
    filtered_df,
    x="Sales",
    y="Profit",
    color="Category",
    size="Quantity",
    hover_name="Product Name",
    title="Sales vs Profit by Product"
)

st.plotly_chart(
    fig,
    use_container_width=True
)


st.subheader("Category Contribution")

fig = px.treemap(
    filtered_df,
    path=["Category", "Sub-Category"],
    values="Sales",
    color="Profit",
    title="Sales Contribution by Category"
)

st.plotly_chart(
    fig,
    use_container_width=True
)


st.subheader("📌 Advanced Insights")

st.info("""
The 3D scatter plot helps identify products
with high sales, high profit, and large order quantities.

Products appearing in the high-sales and high-profit region
represent strong business opportunities.

Products with high sales but low profit may require
pricing or discount strategy review.
""")