import streamlit as st
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt

from utils.data_loader import load_data

df = load_data()

st.title("🏷 Discount Analysis")

tab1, tab2, tab3 = st.tabs(
    [
        "Discount vs Profit",
        "Correlation",
        "Insights"
    ]
)

with tab1:

    st.subheader("Discount vs Profit")

    fig = px.scatter(
        df,
        x="Discount",
        y="Profit",
        color="Category",
        hover_data=["Sub-Category"],
        title="Discount Impact on Profit"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    
    avg_discount = (
        df.groupby("Sub-Category")
        .agg({
            "Discount": "mean",
            "Profit": "mean"
        })
        .reset_index()
    )

    fig = px.bar(
        avg_discount,
        x="Profit",
        y="Sub-Category",
        orientation="h",
        color="Discount",
        title="Average Discount by Sub-Category"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    
with tab2:

    st.subheader("Correlation Matrix")

    corr = df[
        [
            "Sales",
            "Profit",
            "Quantity",
            "Discount"
        ]
    ].corr()
    
    fig, ax = plt.subplots(
        figsize=(8,6)
    )

    sns.heatmap(
        corr,
        annot=True,
        cmap="coolwarm",
        fmt=".2f"
    )

    st.pyplot(fig)
    
    st.info("""
    Correlation ranges from -1 to +1.

    +1 = Strong Positive Relationship

    0 = No Relationship

    -1 = Strong Negative Relationship
    """)
    
with tab3:

    st.subheader("📌 Discount Findings")

    st.success("""
    Small discounts can still maintain strong profitability.
    """)

    st.warning("""
    Higher discounts often reduce profit significantly.
    """)

    st.warning("""
    Discounts above 20%-30% frequently result in losses.
    """)

    st.info("""
    Businesses should optimize discount strategies rather than increasing discounts blindly.
    """)
    
    fig = px.box(
        df,
        x="Category",
        y="Discount",
        color="Category",
        title="Discount Distribution by Category"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    