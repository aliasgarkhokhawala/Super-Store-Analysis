import streamlit as st
import plotly.express as px

from utils.data_loader import load_data

df = load_data()

st.title("🌎 Regional Analysis")
tab1, tab2, tab3 = st.tabs(
    [
        "Region Performance",
        "State Analysis",
        "Insights"
    ]
)

with tab1:

    st.subheader("Sales by Region")

    region_sales = (
        df.groupby("Region")["Sales"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        region_sales,
        x="Region",
        y="Sales",
        color="Region",
        text_auto=".2s",
        title="Sales by Region"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    st.subheader("Profit by Region")

    region_profit = (
        df.groupby("Region")["Profit"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        region_profit,
        x="Region",
        y="Profit",
        color="Region",
        text_auto=".2s",
        title="Profit by Region"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    region_margin = (
        df.groupby("Region")
        .agg(
            Sales=("Sales","sum"),
            Profit=("Profit","sum")
        )
    )

    region_margin["Profit Margin %"] = (
        region_margin["Profit"]
        /
        region_margin["Sales"]
        * 100
    )

    region_margin = (
        region_margin
        .reset_index()
        .sort_values(
            "Profit Margin %",
            ascending=False
        )
    )
    fig = px.pie(
        region_margin,
        names="Region",
        values="Profit Margin %",
        title="Region Profit Margin (%)",
        hole=0.4
)

    fig.update_traces(
        textposition="inside",
        textinfo="percent+label"
)

    st.plotly_chart(
    fig,
    use_container_width=True
)
with tab2:

    st.subheader("Top 10 States by Profit")

    top_states = (
        df.groupby("State/Province")["Profit"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    fig = px.bar(
        top_states,
        x="Profit",
        y="State/Province",
        orientation="h",
        color="Profit",
        title="Top 10 States by Profit"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    st.subheader("Bottom 10 States by Profit")

    bottom_states = (
        df.groupby("State/Province")["Profit"]
        .sum()
        .sort_values()
        .head(10)
        .reset_index()
    )

    fig = px.bar(
        bottom_states,
        x="Profit",
        y="State/Province",
        orientation="h",
        color="Profit",
        title="Bottom 10 States by Profit"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    st.subheader("Profit Distribution")

    fig = px.box(
        df,
        x="Region",
        y="Profit",
        color="Region",
        title="Profit Distribution by Region"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
with tab3:

    st.subheader("📌 Regional Findings")

    st.success("""
    West region achieved the highest profit margin.
    """)

    st.success("""
    East region generated strong sales and profit.
    """)

    st.warning("""
    Central region has the lowest profit margin.
    """)

    st.warning("""
    Texas generated the highest overall loss.
    """)

    st.info("""
    California and New York are major profit contributors.
    """)