import streamlit as st

st.title("📋 Executive Summary")

st.markdown("""
## Business Overview

This project analyzed Superstore sales data to identify
key trends, profitability drivers, customer behavior,
regional performance, and discount impact.
""")

st.divider()


st.header("🔍 Key Findings")

st.success("""
Technology generated the highest sales and profit among all categories.
""")

st.success("""
Copiers were the most profitable sub-category.
""")

st.warning("""
Tables generated significant losses despite strong sales.
""")

st.warning("""
Bookcases also contributed negative profit.
""")

st.info("""
West Region achieved the highest profit margin.
""")

st.info("""
California and New York were the most profitable states.
""")

st.warning("""
Texas generated the highest overall loss.
""")

st.info("""
High discounts frequently reduced profitability.
""")

st.divider()


st.header("👥 Customer Insights")

st.write("""
• Sean Miller generated the highest sales.

• Tamara Chand generated the highest profit.

• High sales customers are not always the most profitable customers.

• Customer profitability should be monitored in addition to revenue.
""")

st.divider()


st.header("🏷 Discount Insights")

st.write("""
• Small discounts can still maintain healthy profits.

• Discounts above 20%-30% often reduce profitability.

• Several categories contain discount outliers.

• Discount strategies should be optimized to protect margins.
""")

st.divider()


st.header("🚀 Business Recommendations")

st.success("""
1. Reduce excessive discounting on low-margin products.
""")

st.success("""
2. Investigate losses in Tables and Bookcases.
""")

st.success("""
3. Focus sales efforts on high-profit products such as Copiers.
""")

st.success("""
4. Study successful practices in the West Region and apply them elsewhere.
""")

st.success("""
5. Strengthen customer retention strategies for top profitable customers.
""")

st.divider()


st.header("✅ Conclusion")

st.write("""
The analysis revealed that profitability is influenced
not only by sales volume but also by discount strategy,
product mix, and regional performance.

By optimizing discounts, focusing on profitable products,
and improving underperforming regions, the company can
increase overall profitability while maintaining sales growth.
""")