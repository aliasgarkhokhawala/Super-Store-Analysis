import streamlit as st
import plotly.express as px

from utils.data_loader import load_data

df = load_data()

st.title("👥 Customer Analysis")

tab1, tab2, tab3 = st.tabs(
    [
        "Sales",
        "Profit",
        "Insights"
    ]
)

with tab1:

    st.subheader("Top 10 Customers by Sales")

    top_sales = (
        df.groupby("Customer Name")["Sales"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    fig = px.bar(
        top_sales,
        x="Sales",
        y="Customer Name",
        orientation="h",
        color="Sales",
        text_auto=".2s",
        title="Top Customers by Sales"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
with tab2:

    st.subheader("Top 10 Customers by Profit")

    top_profit = (
        df.groupby("Customer Name")["Profit"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    fig = px.bar(
        top_profit,
        x="Profit",
        y="Customer Name",
        orientation="h",
        color="Profit",
        text_auto=".2s",
        title="Top Customers by Profit"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    
    customer_compare = (
    df.groupby("Customer Name")
    .agg(
        Sales=("Sales","sum"),
        Profit=("Profit","sum")
    )
    .sort_values("Sales", ascending=False)
    .head(10)
    .reset_index()
    )
    
    fig = px.bar(
    customer_compare,
    x="Customer Name",
    y=["Sales","Profit"],
    barmode="group",
    title="Sales vs Profit by Top Customers"
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )
    
with tab3:

    st.subheader("📌 Customer Insights")

    st.success("""
    Tamara Chand generated the highest profit.
    """)

    st.success("""
    Sean Miller generated the highest sales.
    """)

    st.info("""
    High sales do not always guarantee the highest profit.
    """)

    st.warning("""
    Customer profitability should be considered alongside revenue.
    """)