import streamlit as st
from utils.data_loader import load_data

# -----------------------------------
# PAGE CONFIG
# -----------------------------------

st.set_page_config(
    page_title="Superstore Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -----------------------------------
# LOAD DATA
# -----------------------------------

df = load_data()

# -----------------------------------
# KPI VALUES
# -----------------------------------

total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
total_orders = len(df)
total_customers = df["Customer Name"].nunique()

# -----------------------------------
# HERO SECTION
# -----------------------------------

st.markdown("""
<h1 style='text-align:center;'>
📊 Superstore Analytics Dashboard
</h1>

<p style='text-align:center;
font-size:22px;
color:gray;'>
Sales • Profit • Customer • Regional Insights
</p>
""", unsafe_allow_html=True)

st.divider()

# -----------------------------------
# KPI CARDS
# -----------------------------------

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "💰 Total Sales",
        f"${total_sales:,.0f}"
    )

with col2:
    st.metric(
        "📈 Total Profit",
        f"${total_profit:,.0f}"
    )

with col3:
    st.metric(
        "🛒 Orders",
        f"{total_orders:,}"
    )

with col4:
    st.metric(
        "👥 Customers",
        f"{total_customers:,}"
    )

st.divider()

# -----------------------------------
# ABOUT PROJECT
# -----------------------------------

st.subheader("📌 About This Project")

st.write("""
This project analyzes Superstore sales data to uncover business insights.

The analysis focuses on:

- Category Performance
- Customer Behavior
- Regional Profitability
- Discount Impact
- Sales Trends
- Business Recommendations

The dashboard was built using:

- Python
- Pandas
- Plotly
- Streamlit
""")

st.divider()

# -----------------------------------
# ANALYTICS SECTIONS
# -----------------------------------

st.subheader("🚀 Analytics Modules")

col1, col2 = st.columns(2)

with col1:

    st.success("""
    📦 Category Analysis

    Analyze sales and profit by category and sub-category.
    """)

    st.success("""
    👥 Customer Analysis

    Identify top customers by sales and profitability.
    """)

    st.success("""
    🏷 Discount Analysis

    Understand how discounting affects profit.
    """)

with col2:

    st.info("""
    🌎 Regional Analysis

    Explore regional and state-level performance.
    """)

    st.info("""
    🚀 Advanced Analytics

    Interactive visualizations and 3D analysis.
    """)

    st.info("""
    📋 Executive Summary

    Key findings and business recommendations.
    """)

st.divider()

# -----------------------------------
# FOOTER
# -----------------------------------

st.caption(
    "Developed using Python, Pandas, Plotly and Streamlit"
)